pryeact
=============

#### Esse pacote python converte interfaces gráficas criadas no Qt designer para python usando o conceito de componente.

#### Exemplos


#### Requisitos
#### Pyqt5

#### Instalação

    `pip install pryeact`
    
#### Uso