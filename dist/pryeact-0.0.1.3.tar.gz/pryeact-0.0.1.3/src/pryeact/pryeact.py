
# transformará um arquivo .py gerado pela conversão do QT design em uma tela com seus itens componentizados
class Pryeact:
    def __init__(self, window_path):
        pass
